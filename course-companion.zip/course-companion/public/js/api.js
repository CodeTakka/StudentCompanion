const API = {
  async getSummary() {
    const res = await fetch("/api/dashboard/summary");
    return res.json();
  },

  async getSnapshot() {
    const res = await fetch("/api/dashboard/snapshot");
    return res.json();
  },

  async getCourses() {
    const res = await fetch("/api/dashboard/courses");
    return res.json();
  },

  async getCalendar() {
    const res = await fetch("/api/dashboard/calendar");
    return res.json();
  },

  async getDayItems(date) {
    const res = await fetch(`/api/dashboard/day-items?date=${date}`);
    return res.json();
  }
};