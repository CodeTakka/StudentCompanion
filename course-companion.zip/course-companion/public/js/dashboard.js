document.addEventListener("DOMContentLoaded", async () => {
  await loadSummary();
  await loadSnapshot();
  await loadCourses();
  await loadCalendar();
});

async function loadSummary() {
  const data = await API.getSummary();

  document.getElementById("statCourses").textContent = data.totalCourses ?? 0;
  document.getElementById("statAvgProgress").textContent = `${data.avgProgress ?? 0}%`;
  document.getElementById("statAvgGrade").textContent = `${data.avgGrade ?? 0}%`;
  document.getElementById("statTerm").textContent = data.term ?? "N/A";
}

async function loadSnapshot() {
  const snapshot = await API.getSnapshot();
  const container = document.getElementById("courseSnapshot");

  if (!snapshot) {
    container.innerHTML = "<p>No course data available.</p>";
    return;
  }

  container.innerHTML = `
    <div class="snapshot-card">
      <h3>${snapshot.code}</h3>
      <p><strong>Name:</strong> ${snapshot.name}</p>
      <p><strong>Instructor:</strong> ${snapshot.instructor}</p>
      <p><strong>Term:</strong> ${snapshot.term}</p>
      <p><strong>Average:</strong> ${snapshot.average}%</p>
      <p><strong>Progress:</strong> ${snapshot.progress}%</p>
      <p><strong>Assessments:</strong> ${snapshot.totalAssessments}</p>
    </div>
  `;
}

async function loadCourses() {
  const courses = await API.getCourses();
  const container = document.getElementById("availableCourses");

  if (!courses.length) {
    container.innerHTML = "<p>No courses found.</p>";
    return;
  }

  container.innerHTML = courses
    .map(
      (course) => `
      <div class="card course-card">
        <h3>${course.code} - ${course.name}</h3>
        <p><strong>Instructor:</strong> ${course.instructor}</p>
        <p><strong>Term:</strong> ${course.term}</p>
        <p><strong>Average:</strong> ${course.average}%</p>
        <p><strong>Progress:</strong> ${course.progress}%</p>
      </div>
    `
    )
    .join("");
}

let allCalendarItems = [];
let currentDate = new Date();

async function loadCalendar() {
  allCalendarItems = await API.getCalendar();
  renderCalendar(currentDate);
}

function renderCalendar(date) {
  const calendarGrid = document.getElementById("calendarGrid");
  const calendarTitle = document.getElementById("calendarTitle");

  calendarGrid.innerHTML = "";

  const year = date.getFullYear();
  const month = date.getMonth();

  calendarTitle.textContent = date.toLocaleString("default", {
    month: "long",
    year: "numeric"
  });

  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  for (let i = 0; i < firstDay; i++) {
    const emptyCell = document.createElement("div");
    emptyCell.className = "calendar-day empty";
    calendarGrid.appendChild(emptyCell);
  }

  for (let day = 1; day <= daysInMonth; day++) {
    const cellDate = new Date(year, month, day);
    const isoDate = cellDate.toISOString().split("T")[0];

    const items = allCalendarItems.filter((item) => {
      const itemDate = new Date(item.dueDate).toISOString().split("T")[0];
      return itemDate === isoDate;
    });

    const cell = document.createElement("div");
    cell.className = "calendar-day";
    cell.innerHTML = `
      <div class="day-number">${day}</div>
      ${
        items.length
          ? `<div class="day-badge">${items.length} item${items.length > 1 ? "s" : ""}</div>`
          : ""
      }
    `;

    cell.addEventListener("click", () => showDayItems(isoDate));
    calendarGrid.appendChild(cell);
  }
}

async function showDayItems(date) {
  const items = await API.getDayItems(date);
  const dayItems = document.getElementById("dayItems");
  const label = document.getElementById("selectedDateLabel");

  label.textContent = date;

  if (!items.length) {
    dayItems.innerHTML = "<p>No items due on this date.</p>";
    return;
  }

  dayItems.innerHTML = items
    .map(
      (item) => `
      <div class="day-item">
        <h4>${item.title}</h4>
        <p><strong>Course:</strong> ${item.courseCode} - ${item.courseName}</p>
        <p><strong>Category:</strong> ${item.category}</p>
        <p><strong>Status:</strong> ${item.status}</p>
      </div>
    `
    )
    .join("");
}

document.getElementById("prevMonthBtn")?.addEventListener("click", () => {
  currentDate.setMonth(currentDate.getMonth() - 1);
  renderCalendar(currentDate);
});

document.getElementById("nextMonthBtn")?.addEventListener("click", () => {
  currentDate.setMonth(currentDate.getMonth() + 1);
  renderCalendar(currentDate);
});

document.getElementById("todayBtn")?.addEventListener("click", () => {
  currentDate = new Date();
  renderCalendar(currentDate);
});