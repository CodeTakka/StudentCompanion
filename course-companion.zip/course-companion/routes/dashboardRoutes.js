const express = require("express");
const router = express.Router();

const {
  getSummary,
  getSnapshot,
  getCourses,
  getCalendar,
  getDayItems
} = require("../controllers/dashboardController");

const { protect } = require("../middleware/authMiddleware");

router.get("/summary", protect, getSummary);
router.get("/snapshot", protect, getSnapshot);
router.get("/courses", protect, getCourses);
router.get("/calendar", protect, getCalendar);
router.get("/day-items", protect, getDayItems);

module.exports = router;