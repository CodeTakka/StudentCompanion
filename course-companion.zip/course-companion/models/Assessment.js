const mongoose = require("mongoose");

const assessmentSchema = new mongoose.Schema(
  {
    courseId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Course",
      required: true
    },
    title: {
      type: String,
      required: true,
      trim: true
    },
    category: {
      type: String,
      required: true,
      trim: true
    },
    earnedMarks: {
      type: Number,
      default: 0,
      min: 0
    },
    totalMarks: {
      type: Number,
      required: true,
      min: 1
    },
    dueDate: {
      type: Date,
      required: true
    },
    status: {
      type: String,
      enum: ["completed", "pending"],
      default: "pending"
    }
  },
  { timestamps: true }
);

module.exports = mongoose.model("Assessment", assessmentSchema);